package SMTravelSimulation;
import java.util.HashSet;
/* 
 *  RG.Operator[3] Entity Category    
 */
public class Operator {
	
	// Attributes
	int n; 
	// For implementing the group, use a HashSet object.
	protected HashSet<Operator> group = new HashSet<Operator>(); // RG.Operator[].list
	int uNumOperators; 	//The total number of operators within a day
	int numBusy; 	//The assigned value represents the number of operators that are busy

	int[] schedule; 	//The number of operators starting at each shift
	Operator(int[] schedule){
		this.schedule = schedule; 
	}
	protected enum operatorType {REGULAR, SILVER, GOLD};   //Type of operators
	protected operatorType uOperatorType;
	int operatorType; 
}